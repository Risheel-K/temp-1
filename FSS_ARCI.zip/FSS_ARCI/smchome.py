import synscan
import time


smc=synscan.motors()

smc.goto(0,0)