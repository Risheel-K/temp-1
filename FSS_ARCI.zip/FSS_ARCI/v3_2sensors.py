import synscan
import time
import serial
import csv
import logging
import threading
from rich.live import Live
from rich.table import Table
from rich.panel import Panel
from rich.console import Console
from rich.text import Text
from rich.logging import RichHandler
from rich import box

# ==============================================================================
#  FSS CALIBRATION SCRIPT  — 2-Sensor Version
#  Sensors: Slave 0x11 (S1), 0x12 (S2) on a single RS422 bus
#  Mount:   SkyWatcher AZ-GTi via synscan
#
#  SCAN PATTERN:
#    Alpha (Az) is the OUTER step loop.
#    Beta  (Alt) is the INNER continuous sweep (tracking mode).
#    For each alpha step:
#        1. GOTO (alpha_pos, -beta)     — non-blocking, live countdown shown
#        2. Extra settle wait if needed
#        3. Track beta from -beta → +beta at TRACK_RATE
#           → sample both sensors at each position
#    Alpha steps: alpha_start → +alpha (right), then alpha_start → -alpha (left)
#
#  OUTPUT FILES (3 total):
#    FSS_telemetry_S1.csv  — S1 hex payload + az_deg + alt_deg per row
#    FSS_telemetry_S2.csv  — S2 hex payload + az_deg + alt_deg per row
#    FSS_angles.csv        — all angle records tagged by sensor (shared log)
# ==============================================================================

# ── SCAN GEOMETRY ──────────────────────────────────────────────────────────────
alpha      = 24     # Half-FOV in azimuth (deg). Total Az coverage = ±50° = 100°
delta      = 12     # Alpha step size (deg). Smaller = denser grid, longer run time
beta       = 50     # Half-FOV in elevation (deg). Total El coverage = ±50° = 100°

# ── USER-DEFINED START POSITION ───────────────────────────────────────────────
# 0  = start from boresight (normal full-FOV scan).
# +N = begin right-Az loop at +N°, left-Az loop at +N° stepping toward -alpha.
# -N = begin both loops at -N°.
alpha_start = -24     # deg — EDIT THIS to define your starting alpha column

# ── SAMPLING ───────────────────────────────────────────────────────────────────
nsamples           =  4     # FSS telemetry packets grabbed per mount position
SAMPLE_DELAY       =  0.20  # Seconds between consecutive samples at same position
TRACK_RATE         =  2     # deg/s — beta axis sweep speed

# Extra settle time (seconds) AFTER the mount physically arrives at the GOTO
# target, before the beta sweep begins. smc.goto() already blocks until arrival,
# so this is purely vibration-damping time. Set to 0 if mount is rigid enough.
SETTLE_AFTER_GOTO  =  20     # seconds — adjust to taste

# ── SERIAL / RS422 ─────────────────────────────────────────────────────────────
COM_PORT  = 'COM7'
BAUD_RATE = 115200

# ── TELEMETRY PACKET FORMAT ────────────────────────────────────────────────────
# GetTlm Response = 33 bytes = 264 bits
#   Byte 0      : Start byte  0x23
#   Bytes 1–31  : Payload     (31 bytes of FSS telemetry data)
#   Byte 32     : Stop byte   0x3B
#
# PACKET_PAYLOAD_LEN = 32: read 32 bytes after start byte.
# Bytes at index 0–30 → telemetry_data (31 bytes).
# Byte at index 31    → validated as 0x3B stop byte (not stored).
PACKET_PAYLOAD_LEN = 32     # 31 payload bytes + 1 stop byte

# Commands per sensor — format: 23 <slave_id> 01 00 00 FF FF 3B
SENSOR_IDS = {
    'S1': 0x16,
    'S2': 0x12,
}

def build_command(slave_id: int) -> bytes:
    return bytes([0x23, slave_id, 0x01, 0x00, 0x00, 0xFF, 0xFF, 0x3B])

COMMANDS = {name: build_command(sid) for name, sid in SENSOR_IDS.items()}

# ── OUTPUT FILES ───────────────────────────────────────────────────────────────
# FSS_telemetry_S1/S2.csv : telemetry hex + az_deg + alt_deg (self-contained)
# FSS_angles.csv          : shared angle log tagged by sensor (for cross-checks)
FILENAMES = {
    'S1': 'FSS_telemetry_S1.csv',
    'S2': 'FSS_telemetry_S2.csv',
}
ANGLE_FILENAME = 'FSS_angles.csv'

# ==============================================================================
#  RICH CONSOLE + LOGGING SETUP
#  Route ALL logging (including synscan's) through Rich so it never tears
#  the live display.
# ==============================================================================

console = Console()

logging.basicConfig(
    level    = logging.INFO,
    format   = '%(message)s',
    datefmt  = '[%H:%M:%S]',
    handlers = [RichHandler(console=console, rich_tracebacks=True,
                            show_path=False, markup=False)],
    force    = True,   # override any existing handlers synscan may have set
)

# Suppress synscan's verbose per-command INFO spam — only show WARNING+
logging.getLogger('synscanMotor').setLevel(logging.WARNING)

# ==============================================================================
#  LIVE DISPLAY STATE
# ==============================================================================

state = {
    'phase'            : 'INIT',
    'col_idx'          : 0,
    'total_cols'       : 0,
    'alpha_pos'        : 0.0,
    'beta_pos'         : -float(beta),
    'active_sensor'    : '—',
    'sample_num'       : 0,
    'packets_total'    : 0,
    'col_times'        : [],
    'col_start_t'      : None,
    'scan_start_t'     : None,
    'settle_remaining' : 0,
    'goto_remaining'   : 0,
}


def fmt_dur(secs: float) -> str:
    if secs is None or secs < 0:
        return '—'
    h = int(secs // 3600)
    m = int((secs % 3600) // 60)
    s = int(secs % 60)
    return f'{h:02d}h {m:02d}m {s:02d}s'


def pbar(frac: float, width: int = 30) -> Text:
    frac = max(0.0, min(1.0, frac))
    filled = int(frac * width)
    t = Text()
    t.append('█' * filled,           style='bold green')
    t.append('░' * (width - filled),  style='dim green')
    t.append(f'  {frac * 100:5.1f}%', style='bold cyan')
    return t


def make_display() -> Panel:
    now     = time.time()
    elapsed = now - state['scan_start_t'] if state['scan_start_t'] else 0.0

    col_times = state['col_times']
    avg_col   = (sum(col_times) / len(col_times)) if col_times else \
                (2 * beta / TRACK_RATE) + SETTLE_AFTER_GOTO
    remaining_cols = max(0, state['total_cols'] - state['col_idx'])
    eta = avg_col * remaining_cols

    overall_frac = state['col_idx'] / max(state['total_cols'], 1)
    beta_frac    = (state['beta_pos'] + beta) / (2 * beta)

    tbl = Table(box=None, show_header=False, padding=(0, 2), expand=False)
    tbl.add_column('k', style='bold cyan', min_width=22, no_wrap=True)
    tbl.add_column('v', min_width=40)

    # Phase — colour reflects state
    if 'MOVING' in state['phase']:
        phase_style = 'bold magenta'
    elif 'SETTLING' in state['phase']:
        phase_style = 'bold yellow'
    elif 'SWEEPING' in state['phase']:
        phase_style = 'bold green'
    else:
        phase_style = 'bold cyan'
    tbl.add_row('[dim]PHASE[/dim]', Text(state['phase'], style=phase_style))

    tbl.add_row('[dim]COLUMN[/dim]',
                f"[bold]{state['col_idx']}[/bold] [dim]/ {state['total_cols']}[/dim]")
    tbl.add_row('[dim]OVERALL[/dim]', pbar(overall_frac))
    tbl.add_row('', '')

    tbl.add_row('[dim]ALPHA  (Az)[/dim]',
                f"[bold white]{state['alpha_pos']:+.3f}°[/bold white]")
    tbl.add_row('[dim]BETA   (Alt)[/dim]',
                f"[bold white]{state['beta_pos']:+.3f}°[/bold white]")
    tbl.add_row('[dim]BETA SWEEP[/dim]', pbar(beta_frac))
    tbl.add_row('', '')

    # Sensor indicator — active sensor highlighted
    sensor_parts = []
    for s in SENSOR_IDS:
        if s == state['active_sensor']:
            sensor_parts.append(f'[bold green reverse] {s} [/bold green reverse]')
        else:
            sensor_parts.append(f'[dim] {s} [/dim]')
    tbl.add_row('[dim]SENSORS[/dim]', Text.from_markup('   '.join(sensor_parts)))
    tbl.add_row('[dim]SAMPLE[/dim]',
                f"[bold]{state['sample_num']}[/bold] [dim]/ {nsamples}[/dim]")
    tbl.add_row('[dim]PACKETS LOGGED[/dim]',
                f"[bold]{state['packets_total']:,}[/bold]")
    tbl.add_row('', '')

    tbl.add_row('[dim]ELAPSED[/dim]', f'[white]{fmt_dur(elapsed)}[/white]')
    tbl.add_row('[dim]ETA[/dim]',     f'[bold yellow]{fmt_dur(eta)}[/bold yellow]')

    if state['goto_remaining'] > 0:
        tbl.add_row('[dim]MOUNT MOVING[/dim]',
                    f'[magenta]~{state["goto_remaining"]}s to target...[/magenta]')
    if state['settle_remaining'] > 0:
        tbl.add_row('[dim]SETTLING[/dim]',
                    f'[yellow]{state["settle_remaining"]}s remaining...[/yellow]')

    return Panel(
        tbl,
        title    = '[bold yellow]  ⊙  FSS CALIBRATION — 2-SENSOR  ⊙  [/bold yellow]',
        subtitle = (f'[dim]S1:{hex(SENSOR_IDS["S1"])}  '
                    f'S2:{hex(SENSOR_IDS["S2"])}  '
                    f'{COM_PORT} @ {BAUD_RATE} baud[/dim]'),
        border_style = 'yellow',
        box          = box.ROUNDED,
        padding      = (0, 1),
    )


# ==============================================================================
#  TELEMETRY FETCH
# ==============================================================================

def tmtc(ser: serial.Serial, sensor_name: str) -> str:
    """
    Send a GetTlm command to one FSS sensor and return the 31-byte payload
    as a hex string (62 characters). Returns empty string on framing error.
    """
    ser.reset_input_buffer()
    ser.write(COMMANDS[sensor_name])

    # Phase 1: hunt for start byte 0x23 (max 512 bytes to avoid infinite hang)
    for _ in range(512):
        byte = ser.read(1)
        if byte == b'\x23':
            break
    else:
        console.log(f'[bold red][WARN][/bold red] {sensor_name}: '
                    f'Start byte 0x23 not found — dropping sample')
        return ''

    # Phase 2: read PACKET_PAYLOAD_LEN bytes; last must be stop byte 0x3B
    telemetry_data = b''
    for i in range(PACKET_PAYLOAD_LEN):
        byte = ser.read(1)
        if i == PACKET_PAYLOAD_LEN - 1:
            if byte != b'\x3B':
                console.log(f'[bold red][WARN][/bold red] {sensor_name}: '
                            f'Stop byte expected at index {i}, '
                            f'got 0x{byte.hex()} — packet corrupt')
                return ''
        else:
            telemetry_data += byte

    return telemetry_data.hex()


# ==============================================================================
#  CSV WRITER
#
#  Each sensor's telemetry file is fully self-contained:
#    FSS_telemetry_S1.csv → [telemetry_hex_S1, az_deg, alt_deg]
#    FSS_telemetry_S2.csv → [telemetry_hex_S2, az_deg, alt_deg]
#
#  FSS_angles.csv is a shared cross-reference log:
#    → [sensor, az_deg, alt_deg]
# ==============================================================================

def write_to_csv(sensor_name: str, telemetry: str, angle: list):
    # Telemetry file — hex payload + angles on same row
    with open(FILENAMES[sensor_name], 'a', newline='') as f:
        csv.writer(f).writerow([telemetry, angle[0], angle[1]])

    # Shared angle log — sensor tag + angles
    with open(ANGLE_FILENAME, 'a', newline='') as f:
        csv.writer(f).writerow([sensor_name] + angle)


# ==============================================================================
#  GOTO WITH NON-BLOCKING LIVE COUNTDOWN
# ==============================================================================

def goto_and_wait(az: float, alt: float, live: Live):
    base = (state['phase']
            .replace(' — SWEEPING', '')
            .replace(' — MOVING',   '')
            .replace(' — SETTLING', ''))

    # Estimate travel time for the countdown display
    try:
        cur_az  = smc.axis_get_pos(1)
        cur_alt = smc.axis_get_pos(2)
    except Exception:
        cur_az, cur_alt = state['alpha_pos'], state['beta_pos']

    dist_deg   = max(abs(az - cur_az), abs(alt - cur_alt))
    est_travel = max(5, int(dist_deg / 3.0) + 2)   # AZ-GTi slews ~3°/s

    # Launch goto in background thread so display stays live during travel
    state['phase']          = base + ' — MOVING'
    state['goto_remaining'] = est_travel
    state['alpha_pos']      = az
    state['beta_pos']       = alt
    live.update(make_display())

    done_event = threading.Event()

    def _goto():
        smc.goto(az, alt)
        done_event.set()

    t = threading.Thread(target=_goto, daemon=True)
    t.start()

    tick_start = time.time()
    while not done_event.is_set():
        elapsed_tick = time.time() - tick_start
        state['goto_remaining'] = max(0, int(est_travel - elapsed_tick))
        live.update(make_display())
        time.sleep(0.25)

    t.join()
    state['goto_remaining'] = 0

    # Read actual arrival position
    try:
        state['alpha_pos'] = round(smc.axis_get_pos(1), 3)
        state['beta_pos']  = round(smc.axis_get_pos(2), 3)
    except Exception:
        pass

    # Short vibration-damping settle after arrival
    if SETTLE_AFTER_GOTO > 0:
        state['phase'] = base + ' — SETTLING'
        for remaining in range(SETTLE_AFTER_GOTO, 0, -1):
            state['settle_remaining'] = remaining
            live.update(make_display())
            time.sleep(1)

    state['settle_remaining'] = 0
    live.update(make_display())


# ==============================================================================
#  BETA SWEEP
# ==============================================================================

def scan_beta(ser: serial.Serial, live: Live):
    state['col_start_t'] = time.time()
    base = (state['phase']
            .replace(' — SETTLING', '')
            .replace(' — MOVING',   ''))
    state['phase'] = base + ' — SWEEPING'
    live.update(make_display())

    smc.axis_track(2, TRACK_RATE)
    curr_pos = smc.axis_get_pos(2)

    while curr_pos < beta:
        try:
            pos_az   = smc.axis_get_pos(1)
            curr_pos = smc.axis_get_pos(2)
        except Exception:
            continue

        state['alpha_pos'] = round(pos_az,   3)
        state['beta_pos']  = round(curr_pos, 3)
        angle = [state['alpha_pos'], state['beta_pos']]

        # Sample both sensors at this position before the mount moves on
        for i in range(nsamples):
            state['sample_num'] = i + 1
            for sensor_name in SENSOR_IDS:
                state['active_sensor'] = sensor_name
                live.update(make_display())
                telemetry = tmtc(ser, sensor_name)
                if telemetry:
                    write_to_csv(sensor_name, telemetry, angle)
                    state['packets_total'] += 1
            time.sleep(SAMPLE_DELAY)

    smc.axis_track(2, 0)
    state['col_times'].append(time.time() - state['col_start_t'])


# ==============================================================================
#  MAIN
# ==============================================================================

if __name__ == '__main__':

    if not (-alpha <= alpha_start <= alpha):
        raise ValueError(
            f'alpha_start={alpha_start} is outside ±{alpha}°. '
            f'Set alpha_start between -{alpha} and +{alpha}.'
        )

    right_cols = list(range(alpha_start, alpha + delta, delta))
    left_cols  = list(range(alpha_start, -(alpha + delta), -delta))
    state['total_cols'] = len(right_cols) + len(left_cols)

    # Open serial port once (shared RS422 bus for both sensors)
    ser = serial.Serial(COM_PORT, BAUD_RATE, timeout=2)
    time.sleep(0.5)

    # Init mount
    smc = synscan.motors()
    smc.set_pos(0, 0)

    # Init CSV files with headers
    # Telemetry files include angle columns so each file is self-contained
    for sensor_name, fname in FILENAMES.items():
        with open(fname, 'w', newline='') as f:
            csv.writer(f).writerow([f'telemetry_hex_{sensor_name}',
                                    'az_deg', 'alt_deg'])
    # Shared angle log
    with open(ANGLE_FILENAME, 'w', newline='') as f:
        csv.writer(f).writerow(['sensor', 'az_deg', 'alt_deg'])

    state['scan_start_t'] = time.time()

    with Live(make_display(), console=console,
              refresh_per_second=10, screen=False) as live:

        # RIGHT AZ: alpha_start → +alpha
        state['phase'] = 'RIGHT AZ'
        for x in right_cols:
            state['col_idx'] += 1
            goto_and_wait(x, -beta, live)
            scan_beta(ser, live)

        # Return home
        state['phase'] = 'RETURNING HOME'
        live.update(make_display())
        smc.goto(0, 0)

        # LEFT AZ: alpha_start → -alpha
        state['phase'] = 'LEFT AZ'
        for x in left_cols:
            state['col_idx'] += 1
            goto_and_wait(x, -beta, live)
            scan_beta(ser, live)

        # Final home
        state['phase'] = 'COMPLETE ✓'
        smc.goto(0, 0)
        state['alpha_pos'] = 0.0
        state['beta_pos']  = 0.0
        live.update(make_display())

    ser.close()

    console.print()
    console.rule('[bold green]Data Acquisition Complete[/bold green]')
    console.print(f'  [cyan]Telemetry S1    :[/cyan] {FILENAMES["S1"]}  '
                  f'[dim](hex + az + alt)[/dim]')
    console.print(f'  [cyan]Telemetry S2    :[/cyan] {FILENAMES["S2"]}  '
                  f'[dim](hex + az + alt)[/dim]')
    console.print(f'  [cyan]Angle log       :[/cyan] {ANGLE_FILENAME}  '
                  f'[dim](shared, all sensors)[/dim]')
    console.print(f'  [cyan]Total packets   :[/cyan] {state["packets_total"]:,}')
    console.rule()
