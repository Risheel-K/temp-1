"""
FSS Telemetry Decoder
=====================
Input  : FSS_telemetry_S1.csv  (columns: telemetry_hex_S1, az_deg, alt_deg)
Output : FSS_telemetry_S1_decoded.csv  (all packet fields + az_deg + alt_deg)

Full GetTlm packet (33 bytes):
  Byte  0      : Start Byte 0x23   ← NOT in stored hex
  Bytes 1–31   : 31-byte payload   ← stored as 62-char hex string
  Byte 32      : Stop Byte  0x3B   ← NOT in stored hex

Payload field layout (absolute packet byte → stored payload offset = byte - 1):

  Packet  Stored  Field     Type
  Byte    Offset
  ------  ------  --------  ------
   1       0      SlvID     uint8
   2       1      FnCode    uint8
   3       2      Size_L    uint8
   4       3      Size_H    uint8
   5-6     4-5    Q1        uint16
   7-8     6-7    Q2        uint16
   9-10    8-9    Q3        uint16
  11-12   10-11   Q4        uint16
  13-14   12-13   Temp      uint16
  15      14      Ecl       uint8
  16-17   15-16   CrdX      int16
  18-19   17-18   CrdY      int16
  20-21   19-20   VecX      int16
  22-23   21-22   VecY      int16
  24-25   23-24   VecZ      int16
  26-27   25-26   Alpha     int16
  28-29   27-28   Beta      int16
  30      29      CRC_L     uint8
  31      30      CRC_H     uint8
  32      —       Stop Byte (0x3B, not stored)

All multi-byte fields are little-endian.
"""

import csv
import struct
import sys
from pathlib import Path

# ── CONFIG ─────────────────────────────────────────────────────────────────────
INPUT_FILE  = r"C:\Users\paras.j_dhruvaspace\Desktop\FSS_ARCI\EM16+FM12, a-30,d5,b50\FSS_telemetry_S2.csv"      # edit for S2 if needed
OUTPUT_FILE = 'FSS_telemetry_S2_decoded.csv'

# 31 payload bytes → 62 hex chars
EXPECTED_PAYLOAD_BYTES = 31

# Struct format (little-endian):
#   B  SlvID   uint8
#   B  FnCode  uint8
#   B  Size_L  uint8
#   B  Size_H  uint8
#   H  Q1      uint16
#   H  Q2      uint16
#   H  Q3      uint16
#   H  Q4      uint16
#   H  Temp    uint16
#   B  Ecl     uint8
#   h  CrdX    int16
#   h  CrdY    int16
#   h  VecX    int16
#   h  VecY    int16
#   h  VecZ    int16
#   h  Alpha   int16
#   h  Beta    int16
#   B  CRC_L   uint8
#   B  CRC_H   uint8
STRUCT_FMT    = '<BBBBHHHHHBhhhhhhhBB'
STRUCT_FIELDS = [
    'SlvID', 'FnCode', 'Size_L', 'Size_H',
    'Q1', 'Q2', 'Q3', 'Q4',
    'Temp',
    'Ecl',
    'CrdX', 'CrdY',
    'VecX', 'VecY', 'VecZ',
    'Alpha', 'Beta',
    'CRC_L', 'CRC_H',
]

assert struct.calcsize(STRUCT_FMT) == EXPECTED_PAYLOAD_BYTES, \
    f"Struct size mismatch: {struct.calcsize(STRUCT_FMT)} != {EXPECTED_PAYLOAD_BYTES}"

OUTPUT_FIELDS = (
    ['row']
    + STRUCT_FIELDS
    + ['az_deg', 'alt_deg', 'raw_hex']
)

# ── DECODER ────────────────────────────────────────────────────────────────────

def decode_packet(hex_str: str) -> dict | None:
    """Decode a 31-byte payload hex string into named fields. Returns None on error."""
    hex_str = hex_str.strip()

    if len(hex_str) != EXPECTED_PAYLOAD_BYTES * 2:
        return None

    try:
        raw = bytes.fromhex(hex_str)
    except ValueError:
        return None

    values = struct.unpack_from(STRUCT_FMT, raw)
    return dict(zip(STRUCT_FIELDS, values))


# ── MAIN ───────────────────────────────────────────────────────────────────────

def main():
    input_path  = Path(INPUT_FILE)
    output_path = Path(OUTPUT_FILE)

    if not input_path.exists():
        print(f'[ERROR] Input file not found: {input_path}')
        sys.exit(1)

    ok_rows  = 0
    bad_rows = 0

    with (
        open(input_path,  newline='') as fin,
        open(output_path, 'w', newline='') as fout,
    ):
        reader = csv.DictReader(fin)

        # Auto-detect hex column (works for S1 or S2 file)
        hex_col = next(
            (c for c in (reader.fieldnames or []) if c.startswith('telemetry_hex_')),
            None,
        )
        if hex_col is None:
            print(f'[ERROR] No telemetry_hex_* column found.')
            print(f'        Columns present: {reader.fieldnames}')
            sys.exit(1)

        print(f'  Hex column : {hex_col}')
        print(f'  Input      : {input_path}')
        print(f'  Output     : {output_path}')
        print()

        writer = csv.DictWriter(fout, fieldnames=OUTPUT_FIELDS)
        writer.writeheader()

        for row_num, row in enumerate(reader, start=1):
            hex_str = row.get(hex_col, '').strip()
            az      = row.get('az_deg',  '')
            alt     = row.get('alt_deg', '')

            decoded = decode_packet(hex_str)

            if decoded is None:
                print(f'  [WARN] Row {row_num}: decode failed '
                      f'(hex len={len(hex_str)}, starts with {hex_str[:16]!r})')
                bad_rows += 1
                continue

            decoded['row']     = row_num
            decoded['az_deg']  = az
            decoded['alt_deg'] = alt
            decoded['raw_hex'] = hex_str

            writer.writerow(decoded)
            ok_rows += 1

    print('-' * 45)
    print(f'  Rows decoded OK : {ok_rows:,}')
    print(f'  Rows skipped    : {bad_rows:,}')
    print(f'  Output          : {output_path}')
    print('-' * 45)


if __name__ == '__main__':
    main()
